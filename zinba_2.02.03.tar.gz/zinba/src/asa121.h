void timestamp ( void );
extern "C"{
double trigam ( double x, int *ifault );
}
void trigamma_values ( int *n_data, double *x, double *fx );
